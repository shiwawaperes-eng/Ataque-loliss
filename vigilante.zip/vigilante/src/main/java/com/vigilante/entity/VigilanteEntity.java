package com.vigilante.entity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * El Vigilante: aparece de noche, se queda mirandote unos segundos
 * y despues corre hacia ti. Con la luz del dia desaparece.
 */
public class VigilanteEntity extends Monster {
    private static final int STARE_TICKS = 50;

    private int stareTicks = 0;

    public VigilanteEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 15;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.32D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new StalkMeleeGoal(this, 1.25D));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 32.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void setTarget(@Nullable LivingEntity target) {
        boolean firstSight = this.getTarget() == null && target != null;
        super.setTarget(target);
        if (firstSight && !this.level().isClientSide) {
            this.stareTicks = STARE_TICKS;
            this.playSound(SoundEvents.ENDERMAN_STARE, 1.5F, 0.5F);
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) return;

        // Fase de mirada: se queda quieto clavando los ojos en el jugador
        if (this.stareTicks > 0) {
            this.stareTicks--;
            LivingEntity target = this.getTarget();
            if (target != null) {
                this.getNavigation().stop();
                this.getLookControl().setLookAt(target, 60.0F, 60.0F);
            }
            if (this.stareTicks == 0 && target != null) {
                this.playSound(SoundEvents.WARDEN_ROAR, 1.2F, 0.7F);
            }
        }

        // Oscuridad para los jugadores cercanos
        if (this.tickCount % 20 == 0) {
            List<Player> players = this.level().getEntitiesOfClass(Player.class,
                    this.getBoundingBox().inflate(10.0D));
            for (Player player : players) {
                if (!player.isCreative() && !player.isSpectator()) {
                    player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0, false, false));
                }
            }
        }

        // Con la luz del dia se esfuma
        if (this.level().isDay() && this.level().canSeeSky(this.blockPosition())
                && this.random.nextInt(200) == 0) {
            this.discard();
        }
    }

    public boolean isStaring() {
        return this.stareTicks > 0;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.WARDEN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WARDEN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WARDEN_DEATH;
    }

    @Override
    protected void playStepSound(net.minecraft.core.BlockPos pos, net.minecraft.world.level.block.state.BlockState state) {
        this.playSound(SoundEvents.ZOMBIE_STEP, 0.15F, 0.6F);
    }

    /** Ataque cuerpo a cuerpo que espera mientras el Vigilante esta mirando. */
    private static class StalkMeleeGoal extends MeleeAttackGoal {
        private final VigilanteEntity vigilante;

        StalkMeleeGoal(VigilanteEntity mob, double speed) {
            super(mob, speed, false);
            this.vigilante = mob;
        }

        @Override
        public boolean canUse() {
            return !vigilante.isStaring() && super.canUse();
        }

        @Override
        public boolean canContinueToUse() {
            return !vigilante.isStaring() && super.canContinueToUse();
        }
    }
}
