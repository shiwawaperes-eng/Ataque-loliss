package com.vigilante;

import com.vigilante.entity.VigilanteEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(VigilanteMod.MODID)
public class VigilanteMod {
    public static final String MODID = "vigilante";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<EntityType<VigilanteEntity>> VIGILANTE =
            ENTITIES.register("vigilante", () ->
                    EntityType.Builder.of(VigilanteEntity::new, MobCategory.MONSTER)
                            .sized(0.6F, 1.95F)
                            .clientTrackingRange(10)
                            .build("vigilante"));

    public static final RegistryObject<Item> VIGILANTE_EGG =
            ITEMS.register("vigilante_spawn_egg", () ->
                    new ForgeSpawnEggItem(VIGILANTE, 0x0B0B0B, 0x8B0000, new Item.Properties()));

    public VigilanteMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        bus.addListener(this::onAttributes);
        bus.addListener(this::onSpawnPlacement);
        bus.addListener(this::onCreativeTab);
        MinecraftForge.EVENT_BUS.register(new GameEvents());
    }

    private void onAttributes(EntityAttributeCreationEvent event) {
        event.put(VIGILANTE.get(), VigilanteEntity.createAttributes().build());
    }

    private void onSpawnPlacement(SpawnPlacementRegisterEvent event) {
        event.register(VIGILANTE.get(),
                SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkMonsterSpawnRules,
                SpawnPlacementRegisterEvent.Operation.OR);
    }

    private void onCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(VIGILANTE_EGG);
        }
    }
}
