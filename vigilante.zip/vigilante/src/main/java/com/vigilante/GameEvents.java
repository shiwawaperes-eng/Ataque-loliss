package com.vigilante;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class GameEvents {
    private static final String BOOK_FLAG = "vigilante_book_given";

    private static final String[] PAGES = {
            "MANUAL DE SUPERVIVENCIA\n\nSi estas leyendo esto, ya te encontro.\n\nDe dia estas a salvo. Nadie lo ha visto a la luz del sol.",
            "DE NOCHE\n\nEl Vigilante aparece cuando oscurece. Se queda quieto, a lo lejos, mirandote.\n\nNo lo mires mucho rato.",
            "CUANDO TE VE\n\nTe observa un par de segundos.\nDespues corre hacia ti, sin parar.\n\nNo se cansa. No se rinde.",
            "COMO SOBREVIVIR\n\n- Refugiate antes del anochecer.\n- Ilumina todo con antorchas.\n- Pon bloques entre los dos.\n- Si la pantalla se oscurece, ya esta cerca.",
            "ULTIMA NOTA\n\nAl amanecer se va. Siempre se va.\n\nPero vuelve.\n\nNo escribas su nombre."
    };

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        Player player = event.getEntity();
        if (player.level().isClientSide) return;

        CompoundTag data = player.getPersistentData();
        CompoundTag persisted = data.getCompound(Player.PERSISTED_NBT_TAG);
        if (persisted.getBoolean(BOOK_FLAG)) return;

        persisted.putBoolean(BOOK_FLAG, true);
        data.put(Player.PERSISTED_NBT_TAG, persisted);

        ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
        CompoundTag tag = book.getOrCreateTag();
        tag.putString("title", "Manual de supervivencia");
        tag.putString("author", "Desconocido");
        ListTag pages = new ListTag();
        for (String page : PAGES) {
            pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(page))));
        }
        tag.put("pages", pages);

        if (!player.getInventory().add(book)) {
            player.drop(book, false);
        }
    }
}
