package com.vigilante.client;

import com.vigilante.VigilanteMod;
import com.vigilante.entity.VigilanteEntity;
import net.minecraft.client.model.ZombieModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class VigilanteRenderer extends HumanoidMobRenderer<VigilanteEntity, ZombieModel<VigilanteEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(VigilanteMod.MODID, "textures/entity/vigilante.png");

    public VigilanteRenderer(EntityRendererProvider.Context context) {
        super(context, new ZombieModel<>(context.bakeLayer(ModelLayers.ZOMBIE)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(VigilanteEntity entity) {
        return TEXTURE;
    }
}
